<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DELETE ATTENDANCE</title>
<link rel="stylesheet" type="text/css" href="calendar.css" />
<script type="text/javascript" src="calendar.js"></script>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function checkFrm()
{
	var r = document.myform.subj.options[document.myform.subj.selectedIndex].value;
	var slt = document.myform.slot.options[document.myform.slot.selectedIndex].value;
	var m =r.split(" | ",9);
	
	
	result = confirm("Are You Sure You Want To Delete Attendance Where: Faculty Name: "+m[7]+" "+m[8]+"  Subject Name: "+m[0]+"  Slot: "+slt);
	if(result)
	{
		return true;
	}	
	return false;
}
</script>
<script language="javascript">

function checkFaculty()
{
	
	if(document.myform.faculty.options[0].value==true)
	{
		return false;
	}
	else
	{	
		
		var javaScriptVariable;
		javaScriptVariable=document.myform.faculty.options[document.myform.faculty.selectedIndex].value;
		//document.write(javaScriptVariable);
		window.location.href = "delete_att.php?value=" +javaScriptVariable; 
		document.myform.subj.disabled=false;
		document.myform.subj.focus();
		

	}
}
</script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>
<?php

mysql_connect("localhost","root","shabnam") or die(mysql_error());
mysql_select_db("attendance");

$sql1="SELECT DISTINCT faculty_code,middle_name,first_name,last_name FROM `faculty`"; 
$result1=mysql_query($sql1); 
$ru=mysql_fetch_assoc($result);
$f=$ru['first_name'];
$options1="";
while ($row1=mysql_fetch_array($result1)) { 

    $faculty_code=$row1["faculty_code"]; 
    $first_name=$row1["first_name"];
    $middle_name=$row1["middle_name"];
    $last_name=$row1["last_name"];
    $full_name=$faculty_code." ".$first_name." ".$middle_name." ".$last_name;
	$options1.="<OPTION VALUE=\"$faculty_code\">".strtoupper($full_name); 
}
if(isset($_GET['value']))
{
	session_start();
	$value= $_GET['value']; 
	$_SESSION['get_fac']=$value;
	$get_name="SELECT middle_name,first_name,last_name FROM `faculty` WHERE faculty_code='$value'";
	$name=mysql_query($get_name); 
	
	while ($row_is=mysql_fetch_array($name)) { 
	
    $first_name=$row_is["first_name"];
	$f_name=$first_name;
	$middle_name=$row_is["middle_name"];
    $last_name=$row_is["last_name"];
    $full_names=$first_name."  ".$middle_name."  ".$last_name;
	}
   echo"Faculty Selected: ".strtoupper($full_names);

   	
$cur_year=date('Y');
$valid_year=$cur_year-4;

	$query_get="SELECT s.subject_code,subject_name,s.division,s.year,s.trim,s.branch_name,elective,batch FROM subject,subject_allocation s WHERE faculty_code='$value' AND s.subject_code=subject.subject_code AND year<='$cur_year' AND year>='$valid_year' ORDER BY s.division";
	$result_get=mysql_query($query_get) or die(mysql_error());
	$options2="";
while ($row1=mysql_fetch_array($result_get)) { 


	$subject_code=$row1["subject_code"]; 
    $subject_name=$row1["subject_name"]; 
    $div=$row1["division"];
    $stream=$row1["branch_name"];
	$trim=$row1["trim"];
	$year=$row1["year"];
	$batch=$row1["batch"];
	$elective=$row1["elective"];
	
	$yr="SELECT EXTRACT(YEAR from trim_start) FROM subject_allocation WHERE faculty_code='$value' AND subject_code='$subject_code' AND trim='$trim' AND year='$year' AND division='$div' AND branch_name='$stream' AND batch='$batch'";    $res_yr=mysql_query($yr) or die(mysql_error());
	 
	 while ($row_yr=mysql_fetch_array($res_yr)) { 
	
	$year1=$row_yr['EXTRACT(YEAR from trim_start)'];
	$pass_name=$subject_name." | ".$div." | ".$year." | ".$stream." | ".$trim." | ".$year1." | ".$subject_code." | ".$first_name." | ".$last_name." | ".$batch." | ".$elective;
	
	if($batch==0)
	{
		$batch="Theory";
	}
	
	
    $full_name=$subject_name." | ".$div." | ".$trim." | ".$year." | ".$div."-".$batch;
    $options2.="<OPTION VALUE=\"$pass_name\">".strtoupper($full_name); 
	 }
}
}
?>


<body>
<form name="myform" action="delete_att.php" method="post" onsubmit="return checkFrm()">
<center>
<table width="285" border="0">
  <tr>
    <td>Faculty Name</td>
    <td>
      <label for="faculty"></label>
      <select name="faculty" id="faculty" onchange="checkFaculty()" >
        <option name="initial">Select</option>
        <?=$options1?>
      </select>
      </td>
  </tr>
  <tr>
    <td>Subject Name</td>
    <td><span id="spryselect2">
      <label for="subject_name"></label>
      <select name="subj" id="subj">
        <option name="initial"> subj | div | batch | trim</option>
        <?=$options2?>
      </select>
      <span class="selectRequiredMsg">Please select an item.</span></span></td>
  </tr>
  <tr>
    <td>Slot</td>
    <td><span id="spryselect1">
      <label for="slot"></label>
      <select name="slot" id="slot">
      <option value="initial">Select</option>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      </select>
      <span class="selectRequiredMsg">Please select an item.</span></span></td>
  </tr>
  <tr>
    <td>Date</td>
    <td><span id="sprytextfield1">
      <label for="date_fromit"></label>
      <input type="text" name="date_fromit" id="date_fromit" value="click here!" />
      <script type="text/javascript">
	  calendar.set("date_fromit");
	  </script>
      
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
</table>
<input name="submit" type="submit" id="submit" value="Submit" />
</center>
</form>
<script type="text/javascript">
var spryselect2 = new Spry.Widget.ValidationSelect("spryselect2", {validateOn:["change", "blur"]});
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
</script>
</body>
</html>
<?php
$submit=$_POST['submit'];
if(isset($submit))
{

	session_start();
	$i=0;
	$flag=0;
	$gr=array();
	$roll=array();
	$percentage=array();
	$slot=array();
	$slot_att=array();
	
	$get_fac=$_SESSION['get_fac'];
	$subject_code=$_POST['subj'];
	$slot=$_POST['slot'];
	$date_t=$_POST['date_fromit'];
	$q=mysql_query("SELECT first_name,middle_name,last_name FROM faculty WHERE faculty_code='$get_fac'");
	while($r=mysql_fetch_array($q))
	{
		$fac_name=$r['first_name']." | ".$r['middle_name']." | ".$r['last_name'];
	}
	
	$splitdata = explode(' | ', $subject_code);
	
	$subj=$splitdata[0];
			echo "Subj:".$subj;
	$div=$splitdata[1];
			echo "div:".$div;
	$batch=$splitdata[2];
			echo "batch:".$batch;
	$stream=$splitdata[3];
			echo "Stream:".$stream;
	$trim=$splitdata[4];
			echo "trim:".$trim;
	$year=$splitdata[5];
			echo "year:".$year;
	$sub_code=$splitdata[6];
			echo "sub_code:".$sub_code;
	$ruff=$splitdata[7];
			echo "ruff: ".$ruff;
	$ruff2=$splitdata[8];
			echo "ruff2:".$ruff2;
	$batch_pr=$splitdata[9];
			echo "batch_pr:".$batch_pr;
	$elective=$splitdata[10];
			echo "elective:".$elective;
		
	if($elective=="yes")
	{
		$stream="elective";
		$att_type="att_elective";
	}
	else
	{
	$att_type="attendance";
	}
	
		echo $att_type;
		echo"<center><u>You Selected</u> : ".$fac_name;
		echo"<br/><u>Stream</u> : ".$stream." <u>Trim</u> : ".$trim." <u>Subject</u> : ".$subj." <u>Div</u> :".$div;
		
		$student=mysql_query("SELECT gr_no,roll_no FROM $stream WHERE division='$div' AND trim='$trim' AND year='$batch' ORDER BY roll_no") or die(mysql_error()) or die(mysql_error());
		$qry=mysql_query("SELECT faculty_code,gr_no,subject_code,slot,date FROM $att_type WHERE faculty_code='$get_fac' AND subject_code='$sub_code' AND slot='$slot' AND date='$date_t'") or die(mysql_error());
		while($ro=mysql_fetch_array($qry))
		{
			$fac_code=$ro['faculty_code'];
			$grr=$ro['gr_no'];
			$subb_code=$ro['subject_code'];
			$slott=$ro['slot'];
			$dat=$ro['date'];
		}
		
		
			while($row_stu=mysql_fetch_array($student))
			{
			$gr[$i]=$row_stu['gr_no'];
			$gr_is=$gr[$i];
		
			$att=mysql_query("DELETE FROM $att_type WHERE faculty_code='$get_fac' AND gr_no='$gr_is' AND subject_code='$sub_code' AND slot='$slot' AND date='$date_t'") or die(mysql_error());
			
			
			$i++;
			}
			
			if($att=true)
			{
			echo "<script>alert('Sucessful Deletion!')</script>";
			return true;
			}
			else 
			{
			echo "<script>alert('Error!!')</script>";
			return false;
			}		
		
}
?>